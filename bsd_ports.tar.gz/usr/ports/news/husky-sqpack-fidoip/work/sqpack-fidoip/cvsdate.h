char cvs_date[]="20-03-05";
