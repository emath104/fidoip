--- goldlib/gall/gutlgrp.cpp.orig	2002-09-24 14:16:03.000000000 +0400
+++ goldlib/gall/gutlgrp.cpp	2008-07-18 12:22:34.000000000 +0400
@@ -33,7 +33,7 @@
 #include <string>
 #include <gwildmat.h>
 #include <gutlgrp.h>
-
+#include <string.h>
 
 //  ------------------------------------------------------------------
 //  Constructor
