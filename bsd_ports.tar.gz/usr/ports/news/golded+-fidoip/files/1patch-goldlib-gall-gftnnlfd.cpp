--- goldlib/gall/gftnnlfd.cpp.orig	2000-02-25 13:11:02.000000000 +0300
+++ goldlib/gall/gftnnlfd.cpp	2008-07-18 12:07:38.000000000 +0400
@@ -29,7 +29,7 @@
 #include <gfilutil.h>
 #include <gstrall.h>
 #include <gftnnlfd.h>
-
+#include <stdlib.h>
 
 //  ------------------------------------------------------------------
 
