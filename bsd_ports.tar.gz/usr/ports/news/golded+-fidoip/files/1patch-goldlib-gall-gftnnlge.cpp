--- goldlib/gall/gftnnlge.cpp.orig	2005-11-01 12:26:52.000000000 +0300
+++ goldlib/gall/gftnnlge.cpp	2008-07-18 12:13:24.000000000 +0400
@@ -30,7 +30,7 @@
 #include <gmemdbg.h>
 #include <gstrall.h>
 #include <gftnnlge.h>
-
+#include <stdlib.h>
 
 //  ------------------------------------------------------------------
 
