--- goldlib/gall/gftnnl.cpp.orig	2000-02-25 13:11:01.000000000 +0300
+++ goldlib/gall/gftnnl.cpp	2008-07-18 12:04:06.000000000 +0400
@@ -27,7 +27,7 @@
 #include <cstdio>
 #include <gstrall.h>
 #include <gftnnl.h>
-
+#include <stdlib.h>
 
 //  ------------------------------------------------------------------
 
