--- golded3/golded3.h.orig	2005-08-28 23:24:46.000000000 +0400
+++ golded3/golded3.h	2008-07-18 11:03:34.000000000 +0400
@@ -29,7 +29,7 @@
 
 #ifndef __GOLDED3_H
 #define __GOLDED3_H
-
+#define INT_MAX 214783647
 //  ------------------------------------------------------------------
 //  Global compile constants
 
