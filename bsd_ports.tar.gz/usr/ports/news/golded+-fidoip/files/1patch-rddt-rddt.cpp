--- rddt/rddt.cpp.orig	2007-01-15 15:28:07.000000000 +0300
+++ rddt/rddt.cpp	2008-07-18 12:25:18.000000000 +0400
@@ -38,7 +38,7 @@
 #include <gftnall.h>
 #include <golded3.h>
 #include <gmemdbg.h>
-
+#include <stdlib.h>
 int debug = false;
 
 
