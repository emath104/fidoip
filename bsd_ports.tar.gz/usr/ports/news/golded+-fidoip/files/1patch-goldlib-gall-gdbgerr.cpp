--- goldlib/gall/gdbgerr.cpp.orig	2000-02-25 13:11:57.000000000 +0300
+++ goldlib/gall/gdbgerr.cpp	2008-07-18 11:22:58.000000000 +0400
@@ -28,7 +28,7 @@
 #include <gutlmisc.h>
 #include <gfilutil.h>
 #include <gdbgerr.h>
-
+#include <string.h>
 
 //  ------------------------------------------------------------------
 
