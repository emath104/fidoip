#!/bin/sh
# Start this script with screen
# then it start every 10 seconds ~/.fidoip/xmms-nowplay script to check Amarok and create signiture   
# Usage: screen ~/.fidoip/xmms-start-nowplay.sh

NUMBER=-1
i=1 
NUMBER=$(($NUMBER+1))
while [ "$i" -ne "$NUMBER" ]
do
~/.fidoip/xmms-nowplay
i=$(($i+1))
sleep 10
done
echo
exit 0

