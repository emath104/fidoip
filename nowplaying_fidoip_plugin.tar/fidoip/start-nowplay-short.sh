#!/bin/sh
# Start this script with screen
# then it start every 10 seconds ~/.fidoip/nowplay script to check Amarok and create signiture   
# Usage: screen ~/.fidoip/start-nowplay-short.sh

NUMBER=-1
i=1 
NUMBER=$(($NUMBER+1))
while [ "$i" -ne "$NUMBER" ]
do
~/.fidoip/nowplay-short
i=$(($i+1))
sleep 10
done
echo
exit 0

