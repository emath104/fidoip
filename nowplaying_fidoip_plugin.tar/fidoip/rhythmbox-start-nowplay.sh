#!/bin/sh
# Start this script with screen
# then it start every 10 seconds ~/.fidoip/audacious-nowplay script to check Rhythmbox and create signiture   
# Usage: screen ~/.fidoip/rhythmbox-start-nowplay.sh

NUMBER=-1
i=1 
NUMBER=$(($NUMBER+1))
while [ "$i" -ne "$NUMBER" ]
do
~/.fidoip/rhythmbox-nowplay
i=$(($i+1))
sleep 10
done
echo
exit 0

