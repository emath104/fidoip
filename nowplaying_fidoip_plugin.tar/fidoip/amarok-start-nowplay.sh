#!/bin/sh
# Start this script with screen
# then it start every 10 seconds ~/.fidoip/amarok-nowplay script to check Amarok and create signiture   
# Usage: screen ~/.fidoip/amarok-start-nowplay.sh

NUMBER=-1
i=1 
NUMBER=$(($NUMBER+1))
while [ "$i" -ne "$NUMBER" ]
do
~/.fidoip/amarok-nowplay
i=$(($i+1))
sleep 10
done
echo
exit 0

