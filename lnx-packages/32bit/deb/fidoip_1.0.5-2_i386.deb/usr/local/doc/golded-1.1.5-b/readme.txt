______________________________________________________________________

                         The Goldware Library
                            June 20, 1998
                               READ ME
______________________________________________________________________


Please read LICENSE.TXT for the license for The Goldware Library and
other source code by Odinn Sorensen.

For installation instructions, read INSTALL.TXT.

______________________________________________________________________

