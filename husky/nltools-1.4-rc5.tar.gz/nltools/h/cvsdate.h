char cvs_date[]="09-04-05";
