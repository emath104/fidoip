#ifndef NLDATE_H
#define NLDATE_H

long parse_nodelist_date(char *filename);

#endif
