char cvs_date[]="04-04-05";
