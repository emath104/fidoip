char cvs_date[]="01-04-05";
