#ifndef __PATMAT_H__
#define __PATMAT_H__

#include "compiler.h"
/* released to the public domain */
SMAPI_EXT int patmat(char *raw, char *pat);

#endif
