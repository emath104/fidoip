char cvs_date[]="26-03-05";
