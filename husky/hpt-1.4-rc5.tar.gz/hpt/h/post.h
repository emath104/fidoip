/* $Id: post.h,v 1.5 2002/11/17 01:39:00 stas_degteff Rel $ */

#ifndef _POST_H
#define _POST_H

void post(int c, unsigned int *n, char *params[]);

#endif
