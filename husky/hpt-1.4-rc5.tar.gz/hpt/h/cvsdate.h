char cvs_date[]="16-02-06";
