#ifndef _FILECASE_H
#define _FILECASE_H

#include "fcommon.h"

int isDOSLikeName(char *name);
char *MakeProperCase(char *name);


#endif
