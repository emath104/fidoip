char cvs_date[]="21-01-06";
