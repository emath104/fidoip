/* $Id: log.h,v 1.4.2.2 2004/07/04 23:49:57 d_sergienko Exp $ */

#ifndef _LOG_H
#define _LOG_H

void Log(char level, char *msg,...);
void Debug(char *msg,...);

#endif
