/* $Id: bsoutil.h,v 1.4 2002/09/19 08:00:34 sfpavel Exp $ */

#ifndef _BSOUTIL_H_
#define _BSOUTIL_H_

void packNetMailForLink(s_link *link);
char *addr2str(s_link *link);

#endif
