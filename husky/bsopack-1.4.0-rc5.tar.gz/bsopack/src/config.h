/* $Id: config.h,v 1.7.2.4 2004/07/04 23:48:29 d_sergienko Exp $ */

#ifndef _CONFIG_H
#define _CONFIG_H

#define VER_MAJOR 1
#define VER_MINOR 4
#define VER_PATCH 0
#define VER_BRANCH BRANCH_STABLE

#include <fidoconf/fidoconf.h>

#define MAXPATH 256


extern s_fidoconfig *fidoConfig;
extern char *logFileName;
extern int enable_quiet;
extern int enable_debug;
extern char *fidoConfigFile;
extern char *VERSION;

void getConfig();
void freeConfig();
void getOpts(int argc, char **argv);

#endif
