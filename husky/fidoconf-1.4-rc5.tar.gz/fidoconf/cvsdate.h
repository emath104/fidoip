char cvs_date[]="24-02-06";
