/*
 *  run.h -- Run external programs
 *
 *  run.h is a part of binkd project
 *
 *  Copyright (C) 1996-1997  Dima Maloff, 5047/13
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version. See COPYING.
 */

/*
 * $Id: run.h,v 2.1 2001/10/27 08:07:18 gul Exp $
 *
 * $Log: run.h,v $
 * Revision 2.1  2001/10/27 08:07:18  gul
 * run and run_args returns exit code of calling process
 *
 * Revision 2.0  2001/01/10 12:12:39  gul
 * Binkd is under CVS again
 *
 * Revision 1.1  1997/03/28  06:16:56  mff
 * Initial revision
 *
 */
#ifndef _run_h
#define _run_h

int run (char *);

#endif
